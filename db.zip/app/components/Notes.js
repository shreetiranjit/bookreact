import { useEffect } from "react";
import axios from "axios"; 

export default function Notes(props) {
  const {
    setNotes, 
    editId,
    input,
    important,
    showAll,
    setShowAlltoggle,
    inputhandle,
    submithandle,
    removehandle,
    edithandle,
    handlecheck,
    handleShowAll,
  } = props;
  
  useEffect(() => {
    axios.get('http://localhost:4000/notes')
    .then((response) => {
      console.log(response.data);
      setNotes(response.data);
    })
  },[])

  return (
    <div>
      <button onClick = { () => setShowAlltoggle(!showAll)} > show {showAll ? "important": "all"} </button> 
      <h2>
        {handleShowAll.map((note) => {
          return (
            <p key={note.id}>
              <h2>Note {note.id}  <button onClick={() => removehandle(note.id)}> Delete </button></h2>
              <button onClick={() => edithandle(note.id)}>Update</button>
              <h6>
                {note.content} {note.important ? "!!!" : ""}{" "}
              </h6>
            </p>
          );
        })}
      </h2>
      <form onSubmit={submithandle}>
        <input
          type="text"
          value={input}
          onChange={inputhandle}
          placeholder="Enter note"
          required
        />{" "}
        <label>
          important
          <input type="checkbox" checked={important} onChange={handlecheck} />
          <button type="submit">{editId === null ? 'Add' : 'Update'}</button>
        </label>
      </form>
    </div>
  );
}
