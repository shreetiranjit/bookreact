self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\Lenovo\\Desktop\\bookreact\\app\\layout.js": [
      "C:\\Users\\Lenovo\\Desktop\\bookreact\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  },
  "cssModules": {
    "C:\\Users\\Lenovo\\Desktop\\bookreact\\app\\page": [
      "C:\\Users\\Lenovo\\Desktop\\bookreact\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  }
}